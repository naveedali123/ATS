package com.atsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
