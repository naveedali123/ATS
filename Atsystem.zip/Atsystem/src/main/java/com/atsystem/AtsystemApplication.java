package com.atsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtsystemApplication.class, args);
	}

}
