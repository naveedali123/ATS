package com.atsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atsystem.model.HRAdmin;
import com.atsystem.repository.Adminrepository;

@Service
public class Adminservice {
	
	@Autowired
	Adminrepository adminrepository;
	
public Boolean validateAdmin(String hradminEmail, String hradminPassword) {
		
		if (adminrepository.findById(hradminEmail).isPresent()) {
			HRAdmin hradmin= adminrepository.findById(hradminEmail).get();
			String dbPassword = hradmin.getHrpassword().toString();
			if (dbPassword.equals(hradminPassword)) {
				return true;
			}
		}
		return false;
	}

}
