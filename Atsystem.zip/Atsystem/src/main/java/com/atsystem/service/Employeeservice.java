package com.atsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.atsystem.model.Employee;
import com.atsystem.repository.Employeerepository;

@Service
public class Employeeservice {
	
	@Autowired
	Employeerepository emprepo;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public void registeremployee(Employee employee) {
		  System.out.println(employee.getEmp_email());
		  emprepo.save(employee);
		  
		  }

	public Employee findComplaintById(int emp_id) {
		Employee employee = emprepo.findById(emp_id).orElse(null);
		return employee;
	}
	public void deleteComplaint(Employee employee) {
		emprepo.delete(employee);
		
	}
	
}
