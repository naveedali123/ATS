package com.atsystem.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.atsystem.model.Attendance;
import com.atsystem.repository.Attendancerepository;

@Service
public class Attendanceserive {

	@Autowired
	Attendancerepository attrepo;

	@Autowired
	JdbcTemplate jdbcTemplate;

	public void addattendance(int emp_id, String check_in, String curdate) {
		jdbcTemplate.update("insert into attendance (check_in,emp_id,date) value (?,?,?)",
				new Object[] { check_in, emp_id, curdate });

	}

	public int findEmployeeById(int emp_id) {
		String sql = "SELECT IF( EXISTS(SELECT distinct emp_id FROM attendance WHERE emp_id=?), 1, 0)";
		@SuppressWarnings("deprecation")
		int check = jdbcTemplate.queryForObject(sql, new Object[] { emp_id }, Integer.class);
		return check;
	}

	public void saveComplaint(String check_out, int emp_id) {
		jdbcTemplate.update("update attendance set check_out=? where emp_id=?", new Object[] { check_out, emp_id });

	}
	
	public List<Attendance> findempByempid(int emp_id, Date date) {
		String sql ="select emp_id,check_in,check_out,date from attendance where emp_id=? and date=?";
		@SuppressWarnings("deprecation")
		List<Attendance> empsearch =  jdbcTemplate.query(sql, new Object[] {emp_id,date}, new RowMapper<Attendance> () {
			public Attendance mapRow(ResultSet rs, int rowNum) throws SQLException{
				Attendance att = new Attendance();
				att.setEmp_id(rs.getInt(1));
				att.setCheck_in(rs.getString(2));
				att.setCheck_out(rs.getString(3));
				att.setDate(rs.getDate(4));

				return att;
				
			}
		});
		return empsearch;
	}

	public List<Attendance> findempBydate(Date date) {
		String sql ="select emp_id,check_in,check_out,date from attendance where date=?";
		@SuppressWarnings("deprecation")
		List<Attendance> empsearchall =  jdbcTemplate.query(sql, new Object[] {date}, new RowMapper<Attendance> () {
			public Attendance mapRow(ResultSet rs, int rowNum) throws SQLException{
				Attendance att = new Attendance();
				att.setEmp_id(rs.getInt(1));
				att.setCheck_in(rs.getString(2));
				att.setCheck_out(rs.getString(3));
				att.setDate(rs.getDate(4));

				return att;
				
			}
		});
		return empsearchall;
	}

	
}
