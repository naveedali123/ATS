package com.atsystem.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class HRAdmin {
	@Id
	private String hremail;
	
	private String hrpassword;

	public String getHremail() {
		return hremail;
	}

	public void setHremail(String hremail) {
		this.hremail = hremail;
	}

	public String getHrpassword() {
		return hrpassword;
	}

	public void setHrpassword(String hrpassword) {
		this.hrpassword = hrpassword;
	}

	
	
	

}
