package com.atsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.atsystem.model.HRAdmin;

@Repository
public interface Adminrepository extends JpaRepository<HRAdmin, String> {

}
