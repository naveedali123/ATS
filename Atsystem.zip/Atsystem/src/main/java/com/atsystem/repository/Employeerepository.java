package com.atsystem.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.atsystem.model.Employee;

@Repository
public interface Employeerepository extends CrudRepository<Employee, Integer> {

}
