package com.atsystem.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.atsystem.model.Attendance;

@Repository
public interface Attendancerepository extends CrudRepository<Attendance, Integer> {
	
}
