package com.atsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.atsystem.model.HRAdmin;
import com.atsystem.service.Adminservice;

@CrossOrigin("*")
@RequestMapping("/admin")
@RestController
public class Admincontroller {
	
	@Autowired
	Adminservice adminservice;
	
	@PostMapping("/login")
	public String validateAdmin(@RequestBody HRAdmin loginDetails) throws NoSuchFieldException {
		
			String HRadminEmail = loginDetails.getHremail();
			String HRadminPassword =  loginDetails.getHrpassword();
			System.out.println(HRadminEmail);
			
			String LoginStatus = adminservice.validateAdmin(HRadminEmail,HRadminPassword );
		
			return LoginStatus;
}

}
