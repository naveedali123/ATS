package com.atsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.atsystem.model.Employee;
import com.atsystem.repository.Employeerepository;
import com.atsystem.service.Employeeservice;

@CrossOrigin("*")
@RequestMapping("/employee")
@RestController
public class Addempcontroller {
	
	@Autowired
	Employeeservice empserive;
	
	@Autowired
	Employeerepository emprepo;
	
	 @PostMapping("/add") 
	 public String registeremployee(@RequestBody Employee employee ) {
	  System.out.println(employee.getEmp_email());
	  empserive.registeremployee(employee);
	  return "Successful";
	  }

	 @GetMapping("/getAllEmployee") 
		public List<Employee> getAllEmployee(){
			List<Employee> complaints = (List<Employee>) emprepo.findAll();
			return complaints;
		}
	 
	 @DeleteMapping("/delete/{emp_id}")
		public @ResponseBody void deleteComplaintById(@PathVariable("emp_id") int emp_id) {
			Employee employee = empserive.findComplaintById(emp_id);
			empserive.deleteComplaint(employee);
	 }
	 
}


