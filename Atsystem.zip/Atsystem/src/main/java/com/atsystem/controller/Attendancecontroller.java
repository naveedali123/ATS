package com.atsystem.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.atsystem.model.Attendance;
import com.atsystem.service.Attendanceserive;

@CrossOrigin("*")
@RequestMapping("/attendance")
@RestController
public class Attendancecontroller {

	@Autowired
	Attendanceserive attserive;

	@PostMapping("/add")
	public String addattendance(@RequestBody Attendance attendance) {
		int emp_id = attendance.getEmp_id();
		String check_in = attendance.getCheck_in();
		Date date = new Date();
		String strDateFormat = "hh:mm:ss a";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		check_in = dateFormat.format(date);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDateTime now = LocalDateTime.now();
		String curdate = dtf.format(now);

		attserive.addattendance(emp_id, check_in, curdate);
		return "Successful";
	}

	@PostMapping("/update")
	public String update(@RequestBody Attendance attendance) {
		int emp_id = attendance.getEmp_id();
		String check_out = attendance.getCheck_out();
		Date date = new Date();
		String strDateFormat = "hh:mm:ss a";
		DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
		check_out = dateFormat.format(date);
		/*
		 * DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		 * LocalDateTime now = LocalDateTime.now(); String curdate = dtf.format(now);
		 */
		int status = attserive.findEmployeeById(emp_id);
		// int datecheck = attserive.findDate(emp_id);
		if (status == 1) {
			attendance.setCheck_out(check_out);
			attserive.saveComplaint(check_out, emp_id);
			return "Check out Done";
		}
		return "Please check in first";
	}

	
	  @PostMapping("/getemployee/byid")
	  public List<Attendance>searchemployeeById(@RequestBody Attendance details){ 
		  int emp_id = details.getEmp_id();	
		  Date date = details.getDate();		 
		  System.out.println("emp_id is -- "+emp_id+"date is ----"+date); 
		  List<Attendance> empsearch = attserive.findempByempid(emp_id,date);
		  return (List<Attendance>) empsearch;
	  }
	 
	  
	 //List<Attendance> empsearch = (List<Attendance>)attserive.findempByemp_id(emp_id); //return (List<Attendance>) empsearch; }
	  @PostMapping("/getallemployee/bydate")
	  public List<Attendance>searchallemployeebydate(@RequestBody Attendance details){ 	
		  Date date = details.getDate();		 
		  System.out.println("date is ----"+date); 
		  List<Attendance> empsearchall = attserive.findempBydate(date);
		  return (List<Attendance>) empsearchall;
	  }
}
